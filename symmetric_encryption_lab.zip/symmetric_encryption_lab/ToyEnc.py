#!/usr/bin/env python3

from base64 import b64encode
from binascii import hexlify
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad

plainText = "Welcome to SCN"

iv = bytearray.fromhex("ffeeddccbbaa00112233445566778899")
key = "hello "

k = key.strip()
print(f"Original key: {k}")

if len(k) < 16:
    key = k + '*' * (16 - len(k))
    print(f"Padded key: {key}\n")

cipher = AES.new(
    key=bytearray(key, encoding='utf-8'),
    mode=AES.MODE_CBC,
    iv=iv
)

original_ciphertext = cipher.encrypt(
    pad(plainText.encode('utf-8'), AES.block_size)
)

ciphertext_base64 = b64encode(original_ciphertext).decode("utf-8")

print("Ciphertext in Base64:", ciphertext_base64)
print("Ciphertext in Hex:", hexlify(original_ciphertext), "\n")

cipher = AES.new(
    key=bytearray(key, encoding='utf-8'),
    mode=AES.MODE_CBC,
    iv=iv
)

decodedText = unpad(
    cipher.decrypt(original_ciphertext),
    AES.block_size
).decode("utf-8")

print("Decrypted Text:", decodedText)

if decodedText == plainText:
    print("SUCCESS: decrypted text matches the original plaintext")
else:
    print("ERROR: decrypted text does not match the original plaintext")
    

