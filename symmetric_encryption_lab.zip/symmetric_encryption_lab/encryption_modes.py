#!/usr/bin/env python3

import os
import time
import binascii
import subprocess

plaintext = "Sept_24!"
key = "3518a7fa4b7fff79de0ce375a579eec1"
iv = "a2e40ca82add7fff5323805f75388b75"

modes = ["ECB", "CBC", "CFB", "OFB"]

# Write plaintext file
with open("plaintext.txt", "w") as f:
    f.write(plaintext)


def run_cmd_subprocess(cmd):
    subprocess.run(cmd, shell=True)


def file_check(file_path):
    while not os.path.isfile(file_path):
        time.sleep(1)

    with open(file_path, "rb") as f:
        content = f.read()

    print("File content is: {}".format(content))
    print("File HexDump is: {}".format(binascii.hexlify(content).decode()))
    print()


for mode in modes:

    print("------------{}------------".format(mode))

    # Encryption command
    encryption_cmd = (
        f"openssl enc -aes-256-{mode.lower()} "
        f"-K {key} -iv {iv} "
        f"-in plaintext.txt "
        f"-out ciphertext_{mode}.txt"
    )

    run_cmd_subprocess(encryption_cmd)

    print("Encrypted file contents:")
    file_check(f"ciphertext_{mode}.txt")

    # Decryption command
    decryption_cmd = (
        f"openssl enc -aes-256-{mode.lower()} -d "
        f"-K {key} -iv {iv} "
        f"-in ciphertext_{mode}.txt "
        f"-out plaintext_{mode}.txt"
    )

    run_cmd_subprocess(decryption_cmd)

    print("Decrypted file contents:")
    file_check(f"plaintext_{mode}.txt")
